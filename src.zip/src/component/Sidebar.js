//importing css and js
import '../assets/css/color-1.css'
import '../assets/css/style.css'
import '../assets/js/script'

const Sidebar = () => {
    return (
        <div>
            <div className="aside">
                <div className='logo'>
                    <a href='#'><span>T</span>ausif</a>
                </div>

                <div className='nav-toggler'>
                    <span></span>
                </div>

                <ul className='nav'>
                    <li><a href="#" className="active"><i className='fa fa-home'></i>Home</a></li>
                    <li><a href="#"><i className='fa fa-user'></i>About</a></li>
                    <li><a href="#"><i className='fa fa-list'></i>Services</a></li>
                    <li><a href="#"><i className='fa fa-briefcase'></i>Portfolio</a></li>
                    <li><a href="#"><i className='fa fa-comments'></i>Contact</a></li>
                </ul>
            </div>
        </div>
    )
}


export default Sidebar;


